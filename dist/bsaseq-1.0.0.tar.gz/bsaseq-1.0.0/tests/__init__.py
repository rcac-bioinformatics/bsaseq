"""Test suite for bsaseq."""
