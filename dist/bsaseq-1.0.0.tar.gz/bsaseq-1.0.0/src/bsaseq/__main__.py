"""Entry point for running bsaseq as a module.

This allows running the package with:
    python -m bsaseq
"""

from bsaseq.cli import main

if __name__ == "__main__":
    main()
