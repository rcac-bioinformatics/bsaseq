"""Core data structures and statistical functions for bsaseq."""

from bsaseq.core.models import Variant, Window

__all__ = ["Variant", "Window"]
